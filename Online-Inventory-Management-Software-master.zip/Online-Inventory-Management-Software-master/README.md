# Online-Inventory-Management-Software
Online Inventory Management Software using python3.6 (flask) and ajax 


to run this application you have to :

1 > create a virtual environment in python and run 
pip3 install -r requirements.txt

2 > to start the project type >

python3.6 run.py 

3> open your browser and type 
http://0.0.0.0:5000/

login page

![login](https://user-images.githubusercontent.com/33250522/66852816-709fc900-ef9b-11e9-907f-0fb76503497f.png)

register page

![register](https://user-images.githubusercontent.com/33250522/66852935-bceb0900-ef9b-11e9-8c41-89fc2a1c32ae.png)

dashboard page

![Screenshot from 2019-10-15 22-26-20](https://user-images.githubusercontent.com/33250522/66853001-eb68e400-ef9b-11e9-85b7-6bd46eb2878a.png)

make order 


![Screenshot from 2019-10-15 22-25-16](https://user-images.githubusercontent.com/33250522/66853079-15baa180-ef9c-11e9-8ed9-e846e20a2e3f.png)


manage orders 

![Screenshot from 2019-10-15 22-26-53](https://user-images.githubusercontent.com/33250522/66853114-2834db00-ef9c-11e9-937a-c4fad97ace81.png)

add product and manage products 


![Screenshot from 2019-10-15 22-26-35](https://user-images.githubusercontent.com/33250522/66853182-48fd3080-ef9c-11e9-9485-515aee19f5b7.png)
