# FlaskTask

A note-taking and task management web application written in Flask with Bootstrap.

To run this application run from the parent directory:

`flask --app flasktask run`

or

`flask --app flasktask run --debug `

to run in debug mode.
