# BuildoGYM

This project is simply based on Gym Management System and it is a dynamic website using python technology like ***flask***.

### Modules:

##### Admin Login:
Admin can log in to manage Gym members with the modules Like Add Package, Add Shift, Add User, Add Trainers, Payment, Manage Attendance and view all the reports.

##### Administration: 
There would be some submodule under the Administration module.  
* Add Packages  
* Add Shift  
* Add User  
* Add Trainers   
* Manage Payment  
* Manage Attendance

##### Reports: 
Admin can view reports for all.  

### Technologies:  
1) ***Front-End*** : HTML, CSS and JavaScript  
2) ***Back-End*** : Python flask  
3) ***Database*** : SQLite














