# flask_task-management_application
pip install virtualenv
virtualenv venv
source venv/bin/activate
pip install -r requirements.txt

Database flavour Used : MYSQL

App Accesible at : http://15.206.225.172:8013

Author:
Name - Aman Gupta
Email: guptaaman062@gmail.com
Contact - +91-9045190804