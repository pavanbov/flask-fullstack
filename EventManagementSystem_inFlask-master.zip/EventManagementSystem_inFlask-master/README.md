# EventManagementSystem_inFlask
My first Project using a backed framework ie Pythons Flask and using flask_mysqlDB as data base
