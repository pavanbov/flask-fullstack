import React from "react";
import styled, { css } from "styled-components";

const MobileFilterOptions = ({ props }) => {
  return (
    <>
      <Wrapper></Wrapper>
    </>
  );
};

export default MobileFilterOptions;

const Wrapper = styled.div``;
