# Utils

This folder was intended to be used for helpful utilities in the backend. We only ended up adding one file for error checking argument parser types. This argparser_types.py file was only used one time in the Courses Resource located in courses.py.
