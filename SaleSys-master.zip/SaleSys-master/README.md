# SaleSys
Simple and modern inventory and sales management system written in Flask, Python and JS
