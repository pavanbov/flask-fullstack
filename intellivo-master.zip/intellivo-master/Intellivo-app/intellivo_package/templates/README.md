# Template files 

* layout.html
  * main website design. Is inherited by all other template files 
* home.html
  * home page for entire site
* form.html
  * form for profile preference
* login.html
  * form for user log in 
* register.html 
  * form to register a new user 
* userChats.html
  * currently used to get to form.html
  * will be where all chats for a user is 
* about.html
  * about page for website mission 
* profile.html
