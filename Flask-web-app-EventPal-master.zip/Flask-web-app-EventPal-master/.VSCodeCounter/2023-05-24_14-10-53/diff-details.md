# Diff Details

Date : 2023-05-24 14:10:53

Directory d:\\PBL_test\\event_name

Total : 8 files,  16 codes, 16 comments, 4 blanks, all 36 lines

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [event_name/__init__.py](/event_name/__init__.py) | Python | 0 | 0 | -2 | -2 |
| [event_name/templates/enrollment.html](/event_name/templates/enrollment.html) | HTML | 32 | 0 | 7 | 39 |
| [event_name/templates/event.html](/event_name/templates/event.html) | HTML | -3 | 3 | 0 | 0 |
| [event_name/templates/event_info.html](/event_name/templates/event_info.html) | HTML | -3 | 3 | 0 | 0 |
| [event_name/templates/home.html](/event_name/templates/home.html) | HTML | -3 | 3 | 0 | 0 |
| [event_name/templates/layout.html](/event_name/templates/layout.html) | HTML | -1 | 1 | -1 | -1 |
| [event_name/templates/org_events.html](/event_name/templates/org_events.html) | HTML | -3 | 3 | 0 | 0 |
| [event_name/templates/search.html](/event_name/templates/search.html) | HTML | -3 | 3 | 0 | 0 |

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details