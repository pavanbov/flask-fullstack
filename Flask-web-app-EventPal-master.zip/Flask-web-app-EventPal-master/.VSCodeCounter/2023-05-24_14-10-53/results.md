# Summary

Date : 2023-05-24 14:10:53

Directory d:\\PBL_test\\event_name

Total : 23 files,  1616 codes, 289 comments, 284 blanks, all 2189 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| HTML | 17 | 1,071 | 84 | 100 | 1,255 |
| Python | 5 | 349 | 193 | 136 | 678 |
| CSS | 1 | 196 | 12 | 48 | 256 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 23 | 1,616 | 289 | 284 | 2,189 |
| . (Files) | 5 | 349 | 193 | 136 | 678 |
| static | 1 | 196 | 12 | 48 | 256 |
| templates | 17 | 1,071 | 84 | 100 | 1,255 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)