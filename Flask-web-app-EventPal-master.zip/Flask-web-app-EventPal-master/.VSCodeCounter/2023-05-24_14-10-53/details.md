# Details

Date : 2023-05-24 14:10:53

Directory d:\\PBL_test\\event_name

Total : 23 files,  1616 codes, 289 comments, 284 blanks, all 2189 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [event_name/__init__.py](/event_name/__init__.py) | Python | 21 | 0 | 7 | 28 |
| [event_name/forms.py](/event_name/forms.py) | Python | 50 | 79 | 18 | 147 |
| [event_name/models.py](/event_name/models.py) | Python | 41 | 47 | 26 | 114 |
| [event_name/routes.py](/event_name/routes.py) | Python | 237 | 52 | 83 | 372 |
| [event_name/static/main.css](/event_name/static/main.css) | CSS | 196 | 12 | 48 | 256 |
| [event_name/templates/about.html](/event_name/templates/about.html) | HTML | 55 | 1 | 8 | 64 |
| [event_name/templates/account.html](/event_name/templates/account.html) | HTML | 62 | 0 | 6 | 68 |
| [event_name/templates/base.html](/event_name/templates/base.html) | HTML | 29 | 35 | 3 | 67 |
| [event_name/templates/create_event.html](/event_name/templates/create_event.html) | HTML | 62 | 0 | 0 | 62 |
| [event_name/templates/customer_care.html](/event_name/templates/customer_care.html) | HTML | 149 | 0 | 7 | 156 |
| [event_name/templates/email.html](/event_name/templates/email.html) | HTML | 26 | 0 | 2 | 28 |
| [event_name/templates/enrolled_events.html](/event_name/templates/enrolled_events.html) | HTML | 49 | 0 | 6 | 55 |
| [event_name/templates/enrollment.html](/event_name/templates/enrollment.html) | HTML | 36 | 0 | 8 | 44 |
| [event_name/templates/event.html](/event_name/templates/event.html) | HTML | 55 | 3 | 5 | 63 |
| [event_name/templates/event_info.html](/event_name/templates/event_info.html) | HTML | 78 | 3 | 6 | 87 |
| [event_name/templates/event_status.html](/event_name/templates/event_status.html) | HTML | 32 | 0 | 8 | 40 |
| [event_name/templates/home.html](/event_name/templates/home.html) | HTML | 67 | 3 | 8 | 78 |
| [event_name/templates/layout.html](/event_name/templates/layout.html) | HTML | 106 | 33 | 8 | 147 |
| [event_name/templates/login.html](/event_name/templates/login.html) | HTML | 50 | 0 | 5 | 55 |
| [event_name/templates/org_events.html](/event_name/templates/org_events.html) | HTML | 51 | 3 | 7 | 61 |
| [event_name/templates/register.html](/event_name/templates/register.html) | HTML | 89 | 0 | 6 | 95 |
| [event_name/templates/search.html](/event_name/templates/search.html) | HTML | 75 | 3 | 7 | 85 |
| [event_name/utils.py](/event_name/utils.py) | Python | 0 | 15 | 2 | 17 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)