# Diff Summary

Date : 2023-05-24 14:10:53

Directory d:\\PBL_test\\event_name

Total : 8 files,  16 codes, 16 comments, 4 blanks, all 36 lines

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| HTML | 7 | 16 | 16 | 6 | 38 |
| Python | 1 | 0 | 0 | -2 | -2 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 8 | 16 | 16 | 4 | 36 |
| . (Files) | 1 | 0 | 0 | -2 | -2 |
| templates | 7 | 16 | 16 | 6 | 38 |

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)