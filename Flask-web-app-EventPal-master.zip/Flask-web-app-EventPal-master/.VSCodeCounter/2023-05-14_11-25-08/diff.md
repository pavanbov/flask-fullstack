# Diff Summary

Date : 2023-05-14 11:25:08

Directory d:\\PBL_test\\event_name

Total : 1 files,  7 codes, -8 comments, 1 blanks, all 0 lines

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| CSS | 1 | 7 | -8 | 1 | 0 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 1 | 7 | -8 | 1 | 0 |
| static | 1 | 7 | -8 | 1 | 0 |

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)