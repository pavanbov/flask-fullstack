# Summary

Date : 2023-05-14 11:25:08

Directory d:\\PBL_test\\event_name

Total : 23 files,  1600 codes, 273 comments, 280 blanks, all 2153 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| HTML | 17 | 1,055 | 68 | 94 | 1,217 |
| Python | 5 | 349 | 193 | 138 | 680 |
| CSS | 1 | 196 | 12 | 48 | 256 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 23 | 1,600 | 273 | 280 | 2,153 |
| . (Files) | 5 | 349 | 193 | 138 | 680 |
| static | 1 | 196 | 12 | 48 | 256 |
| templates | 17 | 1,055 | 68 | 94 | 1,217 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)