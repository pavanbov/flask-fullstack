# Diff Details

Date : 2023-05-14 11:25:08

Directory d:\\PBL_test\\event_name

Total : 1 files,  7 codes, -8 comments, 1 blanks, all 0 lines

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [event_name/static/main.css](/event_name/static/main.css) | CSS | 7 | -8 | 1 | 0 |

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details