# Summary

Date : 2023-05-09 13:29:28

Directory d:\\PBL_test\\event_name

Total : 23 files,  1590 codes, 282 comments, 279 blanks, all 2151 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| HTML | 17 | 1,053 | 68 | 94 | 1,215 |
| Python | 5 | 348 | 194 | 138 | 680 |
| CSS | 1 | 189 | 20 | 47 | 256 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 23 | 1,590 | 282 | 279 | 2,151 |
| . (Files) | 5 | 348 | 194 | 138 | 680 |
| static | 1 | 189 | 20 | 47 | 256 |
| templates | 17 | 1,053 | 68 | 94 | 1,215 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)