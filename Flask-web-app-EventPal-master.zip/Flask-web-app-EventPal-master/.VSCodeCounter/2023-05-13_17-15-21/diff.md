# Diff Summary

Date : 2023-05-13 17:15:21

Directory d:\\PBL_test\\event_name

Total : 2 files,  3 codes, -1 comments, 0 blanks, all 2 lines

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| HTML | 1 | 2 | 0 | 0 | 2 |
| Python | 1 | 1 | -1 | 0 | 0 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 2 | 3 | -1 | 0 | 2 |
| . (Files) | 1 | 1 | -1 | 0 | 0 |
| templates | 1 | 2 | 0 | 0 | 2 |

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)