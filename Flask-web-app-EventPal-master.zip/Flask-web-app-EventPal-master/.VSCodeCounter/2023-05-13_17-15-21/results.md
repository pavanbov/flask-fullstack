# Summary

Date : 2023-05-13 17:15:21

Directory d:\\PBL_test\\event_name

Total : 23 files,  1593 codes, 281 comments, 279 blanks, all 2153 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| HTML | 17 | 1,055 | 68 | 94 | 1,217 |
| Python | 5 | 349 | 193 | 138 | 680 |
| CSS | 1 | 189 | 20 | 47 | 256 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 23 | 1,593 | 281 | 279 | 2,153 |
| . (Files) | 5 | 349 | 193 | 138 | 680 |
| static | 1 | 189 | 20 | 47 | 256 |
| templates | 17 | 1,055 | 68 | 94 | 1,217 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)