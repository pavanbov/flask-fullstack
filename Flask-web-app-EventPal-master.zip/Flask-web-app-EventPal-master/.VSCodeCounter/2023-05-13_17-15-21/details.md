# Details

Date : 2023-05-13 17:15:21

Directory d:\\PBL_test\\event_name

Total : 23 files,  1593 codes, 281 comments, 279 blanks, all 2153 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [event_name/__init__.py](/event_name/__init__.py) | Python | 21 | 0 | 9 | 30 |
| [event_name/forms.py](/event_name/forms.py) | Python | 50 | 79 | 18 | 147 |
| [event_name/models.py](/event_name/models.py) | Python | 41 | 47 | 26 | 114 |
| [event_name/routes.py](/event_name/routes.py) | Python | 237 | 52 | 83 | 372 |
| [event_name/static/main.css](/event_name/static/main.css) | CSS | 189 | 20 | 47 | 256 |
| [event_name/templates/about.html](/event_name/templates/about.html) | HTML | 55 | 1 | 8 | 64 |
| [event_name/templates/account.html](/event_name/templates/account.html) | HTML | 62 | 0 | 6 | 68 |
| [event_name/templates/base.html](/event_name/templates/base.html) | HTML | 29 | 35 | 3 | 67 |
| [event_name/templates/create_event.html](/event_name/templates/create_event.html) | HTML | 62 | 0 | 0 | 62 |
| [event_name/templates/customer_care.html](/event_name/templates/customer_care.html) | HTML | 149 | 0 | 7 | 156 |
| [event_name/templates/email.html](/event_name/templates/email.html) | HTML | 26 | 0 | 2 | 28 |
| [event_name/templates/enrolled_events.html](/event_name/templates/enrolled_events.html) | HTML | 49 | 0 | 6 | 55 |
| [event_name/templates/enrollment.html](/event_name/templates/enrollment.html) | HTML | 4 | 0 | 1 | 5 |
| [event_name/templates/event.html](/event_name/templates/event.html) | HTML | 58 | 0 | 5 | 63 |
| [event_name/templates/event_info.html](/event_name/templates/event_info.html) | HTML | 81 | 0 | 6 | 87 |
| [event_name/templates/event_status.html](/event_name/templates/event_status.html) | HTML | 32 | 0 | 8 | 40 |
| [event_name/templates/home.html](/event_name/templates/home.html) | HTML | 70 | 0 | 8 | 78 |
| [event_name/templates/layout.html](/event_name/templates/layout.html) | HTML | 107 | 32 | 9 | 148 |
| [event_name/templates/login.html](/event_name/templates/login.html) | HTML | 50 | 0 | 5 | 55 |
| [event_name/templates/org_events.html](/event_name/templates/org_events.html) | HTML | 54 | 0 | 7 | 61 |
| [event_name/templates/register.html](/event_name/templates/register.html) | HTML | 89 | 0 | 6 | 95 |
| [event_name/templates/search.html](/event_name/templates/search.html) | HTML | 78 | 0 | 7 | 85 |
| [event_name/utils.py](/event_name/utils.py) | Python | 0 | 15 | 2 | 17 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)