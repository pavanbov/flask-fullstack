# Diff Details

Date : 2023-05-13 17:15:21

Directory d:\\PBL_test\\event_name

Total : 2 files,  3 codes, -1 comments, 0 blanks, all 2 lines

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [event_name/routes.py](/event_name/routes.py) | Python | 1 | -1 | 0 | 0 |
| [event_name/templates/customer_care.html](/event_name/templates/customer_care.html) | HTML | 2 | 0 | 0 | 2 |

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details