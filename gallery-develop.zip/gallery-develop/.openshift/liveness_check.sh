#!/usr/bin/sh
ls /gallery-data/thumbnails

exit $?
