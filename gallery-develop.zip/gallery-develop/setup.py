#!/bin/env python
# -*- coding: utf8 -*-

from setuptools import setup

setup(
    setup_requires=['pbr'],
    pbr=True,
)
