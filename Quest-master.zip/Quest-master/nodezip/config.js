module.exports = {

    'secret': 'ilovescotchyscotch',
    // 'database': 'mongodb://noder:noderauth&54;proximus.modulusmongo.net:27017/so9pojyN'

};