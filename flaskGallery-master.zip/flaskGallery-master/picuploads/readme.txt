This file keeps the picuploads directory on git.
