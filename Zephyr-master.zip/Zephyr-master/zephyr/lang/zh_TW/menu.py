t = {

	'menu' : u'選單',

}