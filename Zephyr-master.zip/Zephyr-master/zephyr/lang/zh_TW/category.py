t = {

	'category': u'分類',
	'categories': u'分類',

	'create_category': u'建立新分類',
	'edit_category': u'編輯 &ldquo;%s&rdquo;',

	# form fields
	'title': u'標題',
	'title_explain': u'分類標題。',
	'title_missing': u'請輸入標題',

	'slug': u'縮寫',
	'slug_explain': u'分類的縮寫。',

	'description': u'描述',
	'description_explain': u'分類關於什麼。',

	# messages
	'created': u'分類已新增。',
	'updated': u'分類已更新。',
	'deleted': u'分類已刪除。',
	'delete_error': u'至少要有一個分類。',

}