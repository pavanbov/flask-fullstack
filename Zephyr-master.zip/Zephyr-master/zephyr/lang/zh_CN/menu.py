t = {

	'menu' : u'导航',

}