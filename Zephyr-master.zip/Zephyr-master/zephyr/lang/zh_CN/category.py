t = {

	'category' : u'分类',
	'categories' : u'分类',

	'create_category' : u'建立新分类',
	'edit_category' : u'编辑 &ldquo;%s&rdquo;',

	# form fields
	'title' : u'Title',
	'title_explain' : u'分类名称.',
	'title_missing' : u'请输入分类名称',

	'slug' : u'Slug',
	'slug_explain' : u'分类缩写.',

	'description' : u'描述',
	'description_explain' : u'关于您的分类的描述.',

	# messages
	'created' : u'您的新分类已添加.',
	'updated' : u'您的新分类已更新.',
	'deleted' : u'您的分类已删除.',
	'delete_error' : u'您必须有一个分区.',

}