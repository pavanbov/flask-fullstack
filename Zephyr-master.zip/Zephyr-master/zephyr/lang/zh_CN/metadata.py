t = {

	'metadata' : u'站点设置',
	'metadata_desc' : u'管理您的站点设置',

	'comment_settings' : u'回复',
	'theme_settings' : u'模版',

	# form fields
	'sitename' : u'站点名称',
	'sitename_explain' : u'',
	'sitename_missing' : u'您的网站需要一个名字!',

	'sitedescription' : u'站点描述',
	'sitedescription_explain' : u'',
	'sitedescription_missing' : u'您的网站需要一个描述!',

	'homepage' : u'首页',
	'homepage_explain' : u'',

	'postspage' : u'文章页',
	'postspage_explain' : u'',

	'posts_per_page' : u'每页文章数',
	'posts_per_page_explain' : u'',

	'auto_publish_comments' : u'自动通过回复',
	'auto_publish_comments_explain' : u'',

	'comment_notifications' : u'新回复邮件通知',
	'comment_notifications_explain' : u'',

	'comment_moderation_keys' : u'垃圾信息关键词',
	'comment_moderation_keys_explain' : u'用逗号分隔创建关键字列表到黑名单,评论将被自动设置为垃圾评论.',

	'current_theme' : u'网站模版',
	'current_theme_explain' : u'',

	# messages
	'updated' : u'站点信息已更新',

}