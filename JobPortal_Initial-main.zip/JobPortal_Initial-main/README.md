# JobPortal_Initial
Initial Version of Job Portal
Building a Job Portal Based on Flask
