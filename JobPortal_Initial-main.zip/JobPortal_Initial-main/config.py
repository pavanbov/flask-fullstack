class Config(object):
    SQLALCHEMY_DATABASE_URI = 'D:\JobPortal\careerconnect.sqlite'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
