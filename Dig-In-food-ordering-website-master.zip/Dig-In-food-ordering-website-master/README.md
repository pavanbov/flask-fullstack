# Dig In! Food website

<b>How to run :- </b>
Download the zip file.
Extract It.
Go to current folder , open terminal and <br> write command python run.py

<b>Functionalities:- </b> <br>
Through this website, users can register and subsequently login to place orders from nearby restaurants. <br>
Restaurant manager can get their restaurants registered on the website. <br> 
After approval from the admin, the restaurant will be added to the list of nearby restaurants and will be visible to the users. <br> The restaurant manager can edit their restuarant's menu (change price, add/delete items ) at any time. <br> Restaurants can also accept/reject orders. <br>

<b>Assumptions:- </b> <br>
1. Restaurant Registration can only be done by DigIn Admin. For that Restaurant owners have to contact the digin admin separately. <br>
2. If user/restaurant owner forgets the password, for that they have to contact the digin admin separately. <br>
(Contact Details of admin are provided at bottom) <br>

# Languages used
### Flask-Python Web Framework,HTML, CSS, Bootstrap, Javascript, SQLite3

