function showComments(postId) {
    $(`#commentsModal${postId}`).modal('show');
  }