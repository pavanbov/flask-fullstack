# MovieRecommendationusingFlask
<p>A recommender system is a simple algorithm whose aim is to provide the most relevant information to a user by discovering patterns in a dataset.
It helps us to search our preferred movies among all of these different types of movies and hence reduce the trouble of spending a lot of time searching our favorable movies.</p>


