from movie_recommendation_app import create_app

app = create_app()