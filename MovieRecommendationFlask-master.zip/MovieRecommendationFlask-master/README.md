# MovieRecommendationFlask

This is a Movie recommendation system created in **Flask**. Implemented with a **Postgresql Database**.
Deployed in heroku: https://movierecomendationflask.herokuapp.com/


In this report I detail the tools used in the project
[Report Project](doc/Report.pdf)