# Task-management-app-with-python
Created a web-based task management application using Flask framework. Users can register, log in, add tasks, mark them as complete, and delete tasks.
