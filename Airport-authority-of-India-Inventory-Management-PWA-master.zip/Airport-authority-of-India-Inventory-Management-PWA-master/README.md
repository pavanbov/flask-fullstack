# Airport-authority-of-India-Inventory-Management-PWA
A Inventory Management PWA app using QR code 


------------

# QR CODE DATA 
FORMAT - {"org" : "Airport Authority of India", "sn" : "xxx"}

------------

# DATABASE DESIGN

![Database Design](/screenshot/SIH%20AAoI%20(12).jpg)

------------
# Screenshots of PWA App

**INSTALLATION OF THE APP**

![INSTALLATION OF THE APP](/screenshot/SIH%20AAoI.jpg )

**Home Screen**

![Home Screen](/screenshot/SIH%20AAoI%20(1).jpg )

**QR Scanner Screen**

![QR Scanner Screen](/screenshot/SIH%20AAoI%20(2).jpg )

**QR Scanner Screen(Invalid QR Code Scanned)**

![QR Scanner Screen(Invalid QR Code Scanned)](/screenshot/SIH%20AAoI%20(3).jpg)

**Maintenance Report Screen**

![Maintenance Report Screen](/screenshot/SIH%20AAoI%20(4).jpg )

**Maintenance Report Screen(When Maintenance Report Not Present)**

![Maintenance Report Screen(When Maintenance Report Not Present)](/screenshot/SIH%20AAoI%20(5).jpg)

**Login Screen**

![Login Screen](/screenshot/SIH%20AAoI%20(6).jpg)

**Login Screen(Wrong Credentials)**

![Login Screen(Wrong Credentials)](/screenshot/SIH%20AAoI%20(7).jpg)

**Maintenance Report Update Screen**

![Maintenance Report Update Screen](/screenshot/SIH%20AAoI%20(8).jpg)

**QR Code 1**

![QR Code 1](/screenshot/SIH%20AAoI%20(9).jpg)

**QR Code 1**

![QR Code 2](/screenshot/SIH%20AAoI%20(10).jpg)

**Wrong QR Code**

![Wrong QR Code](/screenshot/SIH%20AAoI%20(11).jpg)
