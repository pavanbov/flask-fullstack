OAuth
=====

.. todo::
    Docstrings (module, models, provider)

.. automodule:: indico.core.oauth


Models
++++++

.. automodule:: indico.core.oauth.models.applications
    :members:
    :undoc-members:

.. automodule:: indico.core.oauth.models.tokens
    :members:
    :undoc-members:
