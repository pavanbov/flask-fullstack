Feature
=======

.. todo::
    Docstrings (module, utilities)

.. automodule:: indico.modules.events.features


Utilities
+++++++++

.. automodule:: indico.modules.events.features.util
    :members:
    :undoc-members:
