Agreement
=========

.. todo::
    Docstrings (module, models, utilities)

.. automodule:: indico.modules.events.agreements


Models
++++++

.. automodule:: indico.modules.events.agreements.models.agreements
    :members:
    :undoc-members:


Utilities
+++++++++

.. automodule:: indico.modules.events.agreements.util
    :members:
    :undoc-members:


Placeholders
++++++++++++

.. automodule:: indico.modules.events.agreements.placeholders
    :members:
    :undoc-members:
