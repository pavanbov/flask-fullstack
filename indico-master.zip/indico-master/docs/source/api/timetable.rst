Timetable
=========

.. todo::
    Docstring (module, models, operations, utilities)

.. automodule:: indico.modules.events.timetable


Models
++++++

.. automodule:: indico.modules.events.timetable.models.breaks
    :members:
    :undoc-members:

.. automodule:: indico.modules.events.timetable.models.entries
    :members:
    :undoc-members:


Operations
++++++++++

.. automodule:: indico.modules.events.timetable.operations
    :members:
    :undoc-members:


Utilities
+++++++++

.. automodule:: indico.modules.events.timetable.util
    :members:
    :undoc-members:

.. automodule:: indico.modules.events.timetable.reschedule
    :members:
    :undoc-members:
