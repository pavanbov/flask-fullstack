Indico fields
=============

.. todo::
    Docstrings to all fields

Indico fields extend from WTForm fields and are used for the special cases where the simple form fields are not enough to cover all needs.

.. automodule:: indico.modules.events.fields
    :members:
    :undoc-members:

.. automodule:: indico.modules.events.abstracts.fields
    :members:
    :undoc-members:

.. automodule:: indico.modules.events.contributions.fields
    :members:
    :undoc-members:

.. automodule:: indico.modules.events.papers.fields
    :members:
    :undoc-members:

.. automodule:: indico.modules.events.sessions.fields
    :members:
    :undoc-members:

.. automodule:: indico.modules.categories.fields
    :members:
    :undoc-members:

.. automodule:: indico.modules.networks.fields
    :members:
    :undoc-members:

.. automodule:: indico.web.forms.fields
    :members:
    :undoc-members:
