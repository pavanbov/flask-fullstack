Event Management
================

.. currentmodule::  indico.modules.events.management.controllers
.. autoclass:: RHManageEventBase
   :members:


.. currentmodule::  indico.modules.events.management.views
.. autoclass:: WPEventManagement
   :members:
