Track
=====

.. todo::
    Docstring (module, models, operations)

.. automodule:: indico.modules.events.tracks


Models
++++++

.. automodule:: indico.modules.events.tracks.models.tracks
    :members:
    :undoc-members:

.. automodule:: indico.modules.events.tracks.models.principals
    :members:
    :undoc-members:


Operations
++++++++++

.. automodule:: indico.modules.events.tracks.operations
    :members:
    :undoc-members:
