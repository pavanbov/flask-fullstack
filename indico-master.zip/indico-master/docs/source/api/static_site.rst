Static site
===========

.. todo::
    Doctrings (module, utilities)

.. automodule:: indico.modules.events.static


Models
++++++

.. automodule:: indico.modules.events.static.models.static
    :members:
    :undoc-members:


Utilities
+++++++++

.. automodule:: indico.modules.events.static.util
    :members:
    :undoc-members:
