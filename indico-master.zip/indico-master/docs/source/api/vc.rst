Video conference
================

.. todo::
    Docstrings (module, models, utilities, plugins, exceptions)

.. automodule:: indico.modules.vc


Models
++++++

.. automodule:: indico.modules.vc.models.vc_rooms
    :members:
    :undoc-members:


Utilities
+++++++++

.. automodule:: indico.modules.vc.util
    :members:
    :undoc-members:


Plugins
+++++++

.. automodule:: indico.modules.vc.plugins
    :members:
    :undoc-members:


Exceptions
++++++++++

.. automodule:: indico.modules.vc.exceptions
    :members:
    :undoc-members:
