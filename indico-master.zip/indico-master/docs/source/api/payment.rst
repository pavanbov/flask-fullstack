Payment
=======

.. todo::
    Docstrings (module, models, plugins)

.. automodule:: indico.modules.events.payment


Models
++++++

.. automodule:: indico.modules.events.payment.models.transactions
    :members:
    :undoc-members:


Utilities
+++++++++

.. automodule:: indico.modules.events.payment.util
    :members:
    :undoc-members:


Plugins
+++++++

.. automodule:: indico.modules.events.payment.plugins
    :members: PaymentPluginMixin
    :undoc-members:
