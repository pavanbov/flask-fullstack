Group
=====

.. todo::
    Docstrings (module)

.. automodule:: indico.modules.groups


Models
++++++

.. automodule:: indico.modules.groups.models.groups
    :members:
    :undoc-members:

.. automodule:: indico.modules.groups.core
    :members:
    :undoc-members:


Utilities
+++++++++

.. automodule:: indico.modules.groups.util
    :members:
    :undoc-members:
