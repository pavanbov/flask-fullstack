Authentication
==============

.. todo::
    Docstrings (module, models, utilities)

.. automodule:: indico.modules.auth


Models
++++++

.. automodule:: indico.modules.auth.models.identities
    :members:
    :undoc-members:

.. automodule:: indico.modules.auth.models.registration_requests
    :members:
    :undoc-members:


Utilities
+++++++++

.. automodule:: indico.modules.auth.util
    :members:
    :undoc-members:
