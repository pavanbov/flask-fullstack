Category
========

.. todo::
    Docstrings (module, model, operations, utilities)

.. automodule:: indico.modules.categories


Models
++++++

.. automodule:: indico.modules.categories.models.categories
    :members:
    :undoc-members:

.. automodule:: indico.modules.categories.models.principals
    :members:
    :undoc-members:

.. automodule:: indico.modules.categories.models.settings
    :members:
    :undoc-members:


Operations
++++++++++

.. automodule:: indico.modules.categories.operations
    :members:
    :undoc-members:


Utilities
+++++++++

.. automodule:: indico.modules.categories.util
    :members:
    :undoc-members:

.. automodule:: indico.modules.categories.serialize
    :members:
    :undoc-members:


Settings
++++++++

.. automodule:: indico.modules.categories.settings
    :members:
    :undoc-members:
