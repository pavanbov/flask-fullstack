Designer
========

.. todo::
    Docstrings (module, models, utilities)

.. automodule:: indico.modules.designer


Models
++++++

.. automodule:: indico.modules.designer.models.images
    :members:
    :undoc-members:

.. automodule:: indico.modules.designer.models.templates
    :members:
    :undoc-members:


Utilities
+++++++++

.. automodule:: indico.modules.designer.util
    :members:
    :undoc-members:

.. automodule:: indico.modules.designer.pdf
    :members:
    :undoc-members:


Placeholders
++++++++++++

.. automodule:: indico.modules.designer.placeholders
    :members:
    :undoc-members:
