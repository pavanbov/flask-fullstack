Session
=======

.. todo::
    Docstrings (module, models, operations, utilities)

.. automodule:: indico.modules.events.sessions


Models
++++++

.. automodule:: indico.modules.events.sessions.models.sessions
    :members:
    :undoc-members:

.. automodule:: indico.modules.events.sessions.models.blocks
    :members:
    :undoc-members:

.. automodule:: indico.modules.events.sessions.models.persons
    :members:
    :undoc-members:

.. automodule:: indico.modules.events.sessions.models.principals
    :members:
    :undoc-members:


Operations
++++++++++

.. automodule:: indico.modules.events.sessions.operations
    :members:
    :undoc-members:


Utilities
+++++++++

.. automodule:: indico.modules.events.sessions.util
    :members:
    :undoc-members:
