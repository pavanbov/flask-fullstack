Request
=======

.. todo::
    Docstrings (module)

.. automodule:: indico.modules.events.requests


Models
++++++

.. automodule:: indico.modules.events.requests.models.requests
    :members:
    :undoc-members:


Utilities
+++++++++

.. automodule:: indico.modules.events.requests.util
    :members:
    :undoc-members:

.. automodule:: indico.modules.events.requests.base
    :members: RequestDefinitionBase
    :undoc-members:
