Survey
======

.. todo::
    Docstrings (module, models)

.. automodule:: indico.modules.events.surveys


Models
++++++

.. automodule:: indico.modules.events.surveys.models.surveys
    :members:
    :undoc-members:

.. automodule:: indico.modules.events.surveys.models.items
    :members:
    :undoc-members:

.. automodule:: indico.modules.events.surveys.models.submissions
    :members:
    :undoc-members:


Operations
++++++++++

.. automodule:: indico.modules.events.surveys.operations
    :members:
    :undoc-members:


Utilities
+++++++++

.. automodule:: indico.modules.events.surveys.util
    :members:
    :undoc-members:
