Note
====

.. todo::
    Docstrings (module, models, utilities)

.. automodule:: indico.modules.events.notes


Models
++++++

.. automodule:: indico.modules.events.notes.models.notes
    :members:
    :undoc-members:


Utilities
+++++++++

.. automodule:: indico.modules.events.notes.util
    :members:
    :undoc-members:
