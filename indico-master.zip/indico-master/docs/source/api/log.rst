Log
===

.. todo::
    Docstrings (module, models, utilities)

.. automodule:: indico.modules.logs


Models
++++++

.. automodule:: indico.modules.logs.models.entries
    :members:
    :undoc-members:


Utilities
+++++++++

.. automodule:: indico.modules.logs.util
    :members:
    :undoc-members:

.. automodule:: indico.modules.logs.renderers
    :members:
    :undoc-members:
