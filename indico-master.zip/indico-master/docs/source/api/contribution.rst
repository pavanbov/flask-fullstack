Contribution
============

.. todo::
    Docstrings (module, models, operations, utilities)

.. automodule:: indico.modules.events.contributions


Models
++++++

.. automodule:: indico.modules.events.contributions.models.contributions
    :members:
    :undoc-members:

.. automodule:: indico.modules.events.contributions.models.fields
    :members:
    :undoc-members:

.. automodule:: indico.modules.events.contributions.models.persons
    :members:
    :undoc-members:

.. automodule:: indico.modules.events.contributions.models.principals
    :members:
    :undoc-members:

.. automodule:: indico.modules.events.contributions.models.references
    :members:
    :undoc-members:

.. automodule:: indico.modules.events.contributions.models.subcontributions
    :members:
    :undoc-members:

.. automodule:: indico.modules.events.contributions.models.types
    :members:
    :undoc-members:


Operations
++++++++++

.. automodule:: indico.modules.events.contributions.operations
    :members:
    :undoc-members:


Utilities
+++++++++

.. automodule:: indico.modules.events.contributions.util
    :members:
    :undoc-members:
