Reminder
========

.. todo::
    Docstrings (module)

.. automodule:: indico.modules.events.reminders


Models
++++++

.. automodule:: indico.modules.events.reminders.models.reminders
    :members:
    :undoc-members:


Utilities
+++++++++

.. automodule:: indico.modules.events.reminders.util
    :members:
    :undoc-members:
