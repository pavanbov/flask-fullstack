Layout
======

.. todo::
    Docstrings (module, models, utilities)

.. automodule:: indico.modules.events.layout


Models
++++++

.. automodule:: indico.modules.events.layout.models.images
    :members:
    :undoc-members:

.. automodule:: indico.modules.events.layout.models.menu
    :members:
    :undoc-members:


Utilities
+++++++++

.. automodule:: indico.modules.events.layout.util
    :members:
    :undoc-members:
