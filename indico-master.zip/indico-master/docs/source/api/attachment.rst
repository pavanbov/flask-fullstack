Attachment
==========

.. todo::
    Docstrings (module, models, operations)

.. automodule:: indico.modules.attachments


Models
++++++

.. automodule:: indico.modules.attachments.models.attachments
    :members:
    :undoc-members:

.. automodule:: indico.modules.attachments.models.folders
    :members:
    :undoc-members:

.. automodule:: indico.modules.attachments.models.principals
    :members:
    :undoc-members:


Operations
++++++++++

.. automodule:: indico.modules.attachments.operations
    :members:
    :undoc-members:


Utilities
+++++++++

.. automodule:: indico.modules.attachments.util
    :members:
    :undoc-members:

.. automodule:: indico.modules.attachments.preview
    :members:
    :undoc-members:
