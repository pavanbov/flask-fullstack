Person
======

.. todo::
    Docstrings (module, operations)

.. automodule:: indico.modules.events.persons


Operations
++++++++++

.. automodule:: indico.modules.events.persons.operations
    :members:
    :undoc-members:


Placeholders
++++++++++++

.. automodule:: indico.modules.events.persons.placeholders
    :members:
    :undoc-members:
