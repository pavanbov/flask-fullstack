News
====

.. todo::
    Docstrings (module, models)

.. automodule:: indico.modules.news


Models
++++++

.. automodule:: indico.modules.news.models.news
    :members:
    :undoc-members:


Utilities
+++++++++

.. automodule:: indico.modules.news.util
    :members:
    :undoc-members:
