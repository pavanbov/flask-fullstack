Extending Indico with plugins
=============================

.. include:: _intro.rst

.. toctree::
   :maxdepth: 1

   Getting started <getting_started.rst>
   plugin.rst
   signals.rst
   models.rst
