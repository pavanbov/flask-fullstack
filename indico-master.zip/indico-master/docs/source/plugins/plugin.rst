Plugin API reference
====================

Indico's plugin system allows you to extend indico with additional
modules which can be installed separately and do not require any
modifications to the indico core itself.

.. automodule:: indico.core.plugins
   :members:
