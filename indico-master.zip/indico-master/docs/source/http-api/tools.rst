HTTP API Tools
==============

.. note::
    API keys and signatures have been deprecated. Please consider using :ref:`api-authentication` instead.

.. deprecated:: 3.0

.. raw:: html
   :file: urlgen.html
