
==============  =====  ================  =======================================================================
Param           Short  Values            Description
==============  =====  ================  =======================================================================
occurrences     occ    yes, no           Include all occurrences of room reservations.
cancelled       cxl    yes, no           If specified only include cancelled (*yes*) or
                                         non-cancelled (*no*) reservations.
rejected        rej    yes, no           If specified only include rejected/non-rejected resvs.
confirmed       `-`    yes, no, pending  If specified only include bookings/pre-bookings with the
                                         given state.
archival        arch   yes, no           If specified only include bookings (not) from the past.
recurring       rec    yes, no           If specified only include bookings which are (not) recurring.
repeating       rep    yes, no           Alias for *recurring*
bookedfor       bf     text (wildcards)  Only include bookings where the *booked for* field matches the
                                         given wildcard string.
occurs          `-`    yyyy-mm-dd        Only include bookings which have a valid occurrence on the given date.
                                         Multiple dates can be separated by commas.
==============  =====  ================  =======================================================================
