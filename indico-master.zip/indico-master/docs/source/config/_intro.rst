Indico is very flexible and many things can be configured/customized
in its configuration file.
