To simply install and use Indico, follow the :ref:`production installation instructions <install-prod>`.
For those who are interested in developing new features and plugins for Indico, check out the
:ref:`development installation instructions <install-dev>`.
