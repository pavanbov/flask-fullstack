.. _install-prod:

Production
==========

.. include:: _intro.rst

.. toctree::
    :maxdepth: 1

    AlmaLinux / RockyLinux <rpm/index.rst>
    Debian / Ubuntu <deb/index.rst>
