.. note::

    Please note that you **must** use Apache if you intend to use SSO using
    Shibboleth. If that's not the case because you do not use SSO at all or
    use e.g. OAuth, OIDC or SAML without Shibboleth, we recommend using nginx.
