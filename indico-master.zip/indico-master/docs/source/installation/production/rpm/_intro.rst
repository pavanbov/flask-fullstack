These guides have been verified to work on **AlmaLinux 9** and **Rocky Linux 9**.

With general Linux knowledge it should be straightforward to adapt them to
other rpm-based distributions such as RHEL.

.. include:: ../_old_distros.rst
