.. warning::
    Older distributions are unsupported. We do not test with them, and things
    may or may not be broken. We do not recommend such distributions unless
    you have a very strong technical reason for it and also the necessary system
    administration knowledge to know how to debug and deal with any compatibility
    issues you may encounter.
