These guides have been verified to work on **Debian 12** (Bookworm), **Ubuntu 22.04 LTS**
(Jammy Jellyfish) and **Ubuntu 24.04 LTS** (Noble Numbat).

.. include:: ../_old_distros.rst
