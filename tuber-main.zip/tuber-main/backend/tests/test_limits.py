def test_limits(client):
    """Make sure that requesting resources with limits return a slice of the result."""
    for i in range(100):
        badge = client.post("/api/event/1/badge", json={
            "legal_name": "Test User {}".format(i)
        }).json
        assert(badge['legal_name'] == "Test User {}".format(i))
    badges = client.get("/api/event/1/badge", query_string={"limit": 10}).json
    assert(len(badges) == 10)
    
def test_offset(client):
    """Make sure that requesting resources with offsets return the correct range of data."""
    for i in range(100):
        badge = client.post("/api/event/1/badge", json={
            "legal_name": "Test User {}".format(i)
        }).json
        assert(badge['legal_name'] == "Test User {}".format(i))
    badges = client.get("/api/event/1/badge", query_string={"offset": 10, "limit": 5, "full": True}).json
    assert(len(badges) == 5)
    assert(badges[0]["legal_name"] == "Test User 10")

    # Test with the default limit of 10
    badges = client.get("/api/event/1/badge", query_string={"offset": 20, "full": True}).json
    assert(len(badges) == 10)
    assert(badges[0]["legal_name"] == "Test User 20")

def test_page(client):
    """Make sure that requesting resources with pagination return the correct data."""
    for i in range(100):
        badge = client.post("/api/event/1/badge", json={
            "legal_name": "Test User {}".format(i)
        }).json
        assert(badge['legal_name'] == "Test User {}".format(i))
    badges = client.get("/api/event/1/badge", query_string={"page": 3, "limit": 15, "full": True}).json
    assert(len(badges) == 15)
    assert(badges[0]["legal_name"] == "Test User 45")

    # Test with the default limit of 10
    badges = client.get("/api/event/1/badge", query_string={"page": 5, "full": True}).json
    assert(len(badges) == 10)
    assert(badges[0]["legal_name"] == "Test User 50")