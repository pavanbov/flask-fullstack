def get_first_name():
    return "Fred"

def get_last_name():
    return "McFredface"

def get_full_name():
    return "Fred McFredface"