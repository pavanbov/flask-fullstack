Tuber
=====

Tuber is an event management system. It helps keep track of your event staff, their jobs and shifts, departments, and attendees.

.. toctree::
    :maxdepth: 2

    module.rst
    api.rst