#!/bin/bash
pip install pytest
pip install coverage
pip install fakeredis
cd frontend
npm install --only=dev