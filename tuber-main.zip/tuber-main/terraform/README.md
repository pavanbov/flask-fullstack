# terraform-aws-tuber-ecs
Terraform module for deploying Tuber into AWS ECS


