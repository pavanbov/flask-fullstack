import UserForm from './users/UserForm.vue'
import UserTable from './users/UserTable.vue'

export {
  UserForm,
  UserTable
}
