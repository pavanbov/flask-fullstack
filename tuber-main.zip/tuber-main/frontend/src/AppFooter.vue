<template>
    <div class="layout-footer">
        <img alt="Logo" src="/images/logo-dark.svg" height="20" class="mr-2" />
        by
        <span class="font-medium ml-2">Hackafé</span>
    </div>
</template>

<script>
export default {
  name: 'AppFooter',
  computed: {
  }
}
</script>

<style scoped>

</style>
