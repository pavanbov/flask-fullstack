# zigui
Emby can do much better.  Drop this !!!
Navidrome can do even much better. Last.fm is supported in server side, wow!!!

A simple music library management system based on flask &amp; python. It provides stream service via simple web page and REST API, which is aimed to help people access their own music collection anywhere. Last.fm/Libre.fm will be supported in server side to scrob listening history.
