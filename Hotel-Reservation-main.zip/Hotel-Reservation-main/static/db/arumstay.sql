create database arumstay;

create database client (
    id int(10),
    first_name varchar(50),
    last_name varchar(50),
    password text(20),
    roles varchar(20)
);

