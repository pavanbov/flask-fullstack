# Hotel-Reservation
build reservation system with flask, bootstrap, and js. there's two roles, admin and customer. the system can store customer reservation data in the database. and also the admin version can add and delete data.
