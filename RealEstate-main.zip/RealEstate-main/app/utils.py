# app/utils.py

# Place utility functions here if needed
